########################
# Assignment 4
# Name and surname: Moipone Dikobe
# Student number: u22685759
########################

# Import the data
lego <- read.csv("lego_sample.csv")

y <- lego$Amazon_Price
x <- lego$Pieces
d <- ifelse(lego$Theme == "City", 0, 1)

# Question 1
Q1 <- cor(x, y)


# Question 2
x_bar <- mean(x)
y_bar <- mean(y)
sx <- sd(x)
sy <- sd(y)

b1 <- (sy / sx) * Q1     # slope
b0 <- y_bar - b1 * x_bar # intercept

Q2a <- b0
Q2b <- b1


# Question 3
Q3 <- b1 * 10


# Question 4
Q4 <- b0 + b1 * 300


# Question 5
model <- lm(y ~ x, data = lego)

# Get Emma's Fashion Shop record
emma <- subset(lego, Set_Name == "Emma's Fashion Shop")
emma_pred <- predict(model, newdata = data.frame(x = emma$Pieces))

# Determine if the model over- or underestimates
if (emma_pred > emma$Amazon_Price) {
  Q5 <- "overestimate"
} else {
  Q5 <- "underestimate"
}


# Question 6
# Scatterplot with fitted regression line
plot(x, y,
     main = "Scatterplot of Amazon Price vs Pieces",
     xlab = "Number of Pieces",
     ylab = "Amazon Price (R)",
     pch = 19,
     col = "blue")
abline(model, col = "red", lwd = 2)


# Question 7
# Interpretation of the intercept
Q7 <- "C"


# Question 8
# a) Null hypothesis for slope parameter
Q8a <- "D"

# b) p-value for slope significance test
Q8b <- summary(model)$coefficients[2, 4]


# Question 9
# Compute test statistic and p-value
b0_se <- summary(model)$coefficients[1, 2]
t_stat <- (b0 - 100) / b0_se
df <- summary(model)$df[2]
Q9a <- 1 - pt(t_stat, df)

# Decision and conclusion
if (Q9a < 0.01) {
  Q9b <- "A"
} else if (Q9a < 0.05) {
  Q9b <- "B"
} else if (Q9a < 0.10) {
  Q9b <- "C"
} else {
  Q9b <- "D"
}


# Question 10
Q10 <- summary(model)$r.squared * 100


# Question 11
theme_model <- lm(y ~ d)
Q11 <- mean(y[d == 1]) 


# Question 12
city_pred <- predict(theme_model, newdata = data.frame(d = 0),
                     interval = "confidence", level = 0.99)
Q12 <- city_pred[1, "upr"]


# Question 13
# Perform an ANOVA to test the overall significance of the regression model
anova_result <- anova(theme_model)

# Extract the p-value for the F-test from the ANOVA result
Q13a <- anova_result$`Pr(>F)`[1]

# b) Decision and conclusion
if (Q13a < 0.1) {
  Q13b <- "B"
} else {
  Q13b <- "C"
}


# Question 14
# Shapiro-Wilk test for normality of residuals
theme_model <- lm(y ~ d, data = lego)
residuals_theme <- resid(theme_model)
Q14 <- shapiro.test(residuals_theme)$p.value

