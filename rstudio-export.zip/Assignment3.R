#####################
# Assignment 3
# Name & Surname: Moipone Dikobe
# Student number u22685759
#####################

# Import the data
coffee <- read.csv("CoffeeTruck.csv")
install.packages("nortest")
# Import the necessary packages
library(nortest)
# Do not import any other packages

# Question 1
# Perform Anderson-Darling test on the Profit variable
ad_result <- ad.test(coffee$Profit)

# a) Assign the p-value to Q1a
Q1a <- ad_result$p.value

# b) Decision and conclusion based on 5% significance level
if (Q1a < 0.05) {
  Q1b <- "A"  # Reject H0: Profit does not follow normal distribution
} else {
  Q1b <- "D"  # Do not reject H0: Profit follows normal distribution
}

# Question 2
# Set the seed for reproducibility
set.seed(15)

# Extract the Profit variable
profit <- coffee$Profit

# Initialize vector to store bootstrap means
Q2 <- numeric(1000)

# Perform bootstrap sampling
for (i in 1:1000) {
  sample_i <- sample(profit, size = length(profit), replace = TRUE)
  Q2[i] <- mean(sample_i)
}

# Question 3
# a) Theoretical probability using normal approximation
# Estimate mean and standard deviation of the sampling distribution
mean_Q2 <- mean(Q2)
sd_Q2 <- sd(Q2)

# Calculate theoretical probability using the normal distribution
Q3a <- pnorm(10, mean_Q2, sd_Q2) - pnorm(2, mean_Q2, sd_Q2)

# b) Empirical probability from the bootstrap sample
Q3b <- mean(Q2 >= 2 & Q2 <= 10)


# Question 4
# Perform one-sample t-test for 90% confidence interval
t_result <- t.test(coffee$Profit, conf.level = 0.90)

# Extract the upper limit of the confidence interval
Q4 <- t_result$conf.int[2]

# Question 5
Q5a <- "C"
Q5b <- "A"  # HA: μ > 350

# Filter data for City Hall location
cityhall <- subset(coffee, Location == "City Hall")

# Perform one-sided t-test: H0: μ = 350 vs HA: μ > 350
t_result <- t.test(coffee$Profit, mu = 350, alternative = "greater")

# Assign the p-value to Q5c
Q5c <- t_result$p.value

# Decision based on p-value
if (Q5c < 0.05) {
  Q5d <- "Yes"  # Sustainable
} else {
  Q5d <- "No"   # Not sustainable
}


# Question 6

# Fit ANOVA model
anova_model <- aov(coffee$Profit ~ coffee$Location, data = coffee)

# a) Mean Square Error (MSE)
Q6a <- summary(anova_model)[[1]]["Residuals", "Mean Sq"]

# b) Test statistic (F-value)
Q6b <- summary(anova_model)[[1]]["Location", "F value"]

# c) Decision and conclusion
# Given p-value < 0.001, reject H0: means are equal
Q6c <- "B"

# d) Next step: perform pairwise comparisons
Q6d <- "C"

# Question 7
# Subset data by music type
alt <- subset(coffee, Music == "Alternative")$Profit
hip <- subset(coffee, Music == "HipHop")$Profit

# a) Alternative hypothesis: μ₁ − μ₂ > 0
Q7a <- "A"

# b) Calculate pooled standard error
n1 <- length(alt)
n2 <- length(hip)
s1 <- var(alt)
s2 <- var(hip)

pooled_var <- ((n1 - 1)*s1 + (n2 - 1)*s2) / (n1 + n2 - 2)
Q7b <- sqrt(pooled_var * (1/n1 + 1/n2))

# c) Test statistic
mean_diff <- mean(alt) - mean(hip)
Q7c <- mean_diff / Q7b

# d) p-value (one-sided t-test)
df <- n1 + n2 - 2
Q7d <- pt(Q7c, df, lower.tail = FALSE)

# e) Decision at 5% significance level
Q7e <- if (Q7d < 0.05) "A" else "D"



